from .tests import CaptchaCase, trivial_challenge  # NOQA
